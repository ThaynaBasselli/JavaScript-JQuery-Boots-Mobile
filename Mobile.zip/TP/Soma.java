public class Soma{
 public static void main (String[]args){
  int n1 = 8;
  int n2 = 5;
  int soma = n1 + n2;
  System.out.println (" A soma e:" +soma);
 }
}