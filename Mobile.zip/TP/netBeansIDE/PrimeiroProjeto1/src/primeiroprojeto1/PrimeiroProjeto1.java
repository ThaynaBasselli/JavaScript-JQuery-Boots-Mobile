
package primeiroprojeto1;

public class PrimeiroProjeto1 {

    
    public static void main(String[] args) {
      int n1 = 2;
      int n2 = 2;
      int soma = n1 + n2;
      int sub = n1 - n2;
      int div = n1 / n2;
      int mult = n1 * n2;
      
      System.out.println("Hello Word!");
      System.out.println("A soma dos números é: " + soma);
      System.out.println("A subtração dos números é: " + sub);
      System.out.println("A divisão dos números é: " + div);
      System.out.println("A multiplicação dos números é: " + mult);
    }
    
}
