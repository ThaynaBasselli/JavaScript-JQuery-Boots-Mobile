public class Nome{
 public static void main (String [] args){
  System.out.println ("Thayna");
  System.out.println ("Desenvolvimento de Sistemas");
 }
}